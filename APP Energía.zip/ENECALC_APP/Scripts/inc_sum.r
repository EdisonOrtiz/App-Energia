inc_sum<-function(x)
{
  r=sqrt(sum(x^2))
}